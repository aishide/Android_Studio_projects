package com.example.activity_lifecycle_aishi;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivityLifeCycle";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnWelcome = findViewById(R.id.btnWelcome);
        btnWelcome.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });

        Button btnExit = findViewById(R.id.btnExit);
        btnExit.setOnClickListener(v -> {
            finish();
        });

        showLogAndToast("onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        showLogAndToast("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        showLogAndToast("onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        showLogAndToast("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        showLogAndToast("onStop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        showLogAndToast("onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showLogAndToast("onDestroy");
        // Log is more reliable for onDestroy as the activity is finishing
        Log.d(TAG, "MainActivity: Activity is being destroyed");
    }

    private void showLogAndToast(String methodName) {
        Log.d(TAG, "MainActivity: " + methodName);
        Toast.makeText(this, "MainActivity: " + methodName, Toast.LENGTH_SHORT).show();
    }
}
