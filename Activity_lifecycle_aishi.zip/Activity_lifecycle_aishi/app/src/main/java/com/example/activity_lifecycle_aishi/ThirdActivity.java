package com.example.activity_lifecycle_aishi;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ThirdActivity extends AppCompatActivity {

    private static final String TAG = "ThirdActivityLifeCycle";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_third);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.third_main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView helloTextView = findViewById(R.id.helloTextView);
        String name = getIntent().getStringExtra("USER_NAME");
        if (name != null) {
            helloTextView.setText("Hello " + name + "!");
        }

        Button btnHome = findViewById(R.id.btnHome);
        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(ThirdActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });

        showLogAndToast("onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        showLogAndToast("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        showLogAndToast("onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        showLogAndToast("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        showLogAndToast("onStop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        showLogAndToast("onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showLogAndToast("onDestroy");
    }

    private void showLogAndToast(String methodName) {
        Log.d(TAG, "ThirdActivity: " + methodName);
        Toast.makeText(this, "ThirdActivity: " + methodName, Toast.LENGTH_SHORT).show();
    }
}
