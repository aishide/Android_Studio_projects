package com.example.contentprovider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button btnInsert, btnShow;
    TextView result;

    Uri uri = Uri.parse("content://com.example.provider");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        result = findViewById(R.id.textView);

        btnInsert = findViewById(R.id.btnInsert);
        btnShow = findViewById(R.id.btnShow);

        btnInsert.setOnClickListener(v -> {

            ContentValues values = new ContentValues();
            values.put("name", editText.getText().toString());

            getContentResolver().insert(uri, values);

            result.setText("Data Inserted");
        });

        btnShow.setOnClickListener(v -> {

            Cursor cursor = getContentResolver().query(uri, null, null, null, null);

            StringBuilder data = new StringBuilder();

            if (cursor != null) {
                while (cursor.moveToNext()) {
                    data.append(cursor.getString(0)).append("\n");
                }
                cursor.close();
            }

            if (data.length() == 0) {
                result.setText("No Data Found");
            } else {
                result.setText(data.toString());
            }
        });
    }
}