package com.example.sqlitestudentapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText editName, editMarks, editId;
    Button btnAdd, btnView, btnUpdate, btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        editName = findViewById(R.id.editName);
        editMarks = findViewById(R.id.editMarks);
        editId = findViewById(R.id.editId);

        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        // ADD
        btnAdd.setOnClickListener(v -> {
            boolean inserted = db.insertData(
                    editName.getText().toString(),
                    editMarks.getText().toString()
            );

            Toast.makeText(this,
                    inserted ? "Inserted" : "Failed",
                    Toast.LENGTH_SHORT).show();
        });

        // VIEW
        btnView.setOnClickListener(v -> {
            Cursor res = db.getAllData();

            if (res.getCount() == 0) {
                showMessage("Error", "No Data Found");
                return;
            }

            StringBuilder buffer = new StringBuilder();
            while (res.moveToNext()) {
                buffer.append("ID: ").append(res.getString(0)).append("\n");
                buffer.append("Name: ").append(res.getString(1)).append("\n");
                buffer.append("Marks: ").append(res.getString(2)).append("\n\n");
            }

            showMessage("Student Data", buffer.toString());
        });

        // UPDATE
        btnUpdate.setOnClickListener(v -> {
            db.updateData(
                    editId.getText().toString(),
                    editName.getText().toString(),
                    editMarks.getText().toString()
            );

            Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
        });

        // DELETE
        btnDelete.setOnClickListener(v -> {
            int deleted = db.deleteData(editId.getText().toString());

            Toast.makeText(this,
                    deleted > 0 ? "Deleted" : "Not Found",
                    Toast.LENGTH_SHORT).show();
        });
    }

    public void showMessage(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .show();
    }
}