package com.example.timerserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button startServiceBtn, stopServiceBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startServiceBtn = findViewById(R.id.startService);
        stopServiceBtn = findViewById(R.id.stopService);

        startServiceBtn.setOnClickListener(v ->
                startService(new Intent(MainActivity.this, TimerService.class)));

        stopServiceBtn.setOnClickListener(v ->
                stopService(new Intent(MainActivity.this, TimerService.class)));
    }
}