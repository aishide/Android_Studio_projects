package com.example.timerserviceapp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;

public class TimerService extends Service {

    int seconds = 0;
    boolean running = false; // changed (better control)

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this, "Service Created", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        running = true; // start running when service starts

        new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(1000);
                    seconds++;

                    // ✅ Run Toast on Main UI Thread
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(() -> {
                        Toast.makeText(getApplicationContext(),
                                "Timer: " + seconds + " seconds",
                                Toast.LENGTH_SHORT).show();
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false; // stop loop
        Toast.makeText(this, "Service Stopped", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}